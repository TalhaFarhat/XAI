import xgboost as xgb
import sklearn.datasets  
import pandas as pd
from sklearn.model_selection import train_test_split
import re
import shap
import numpy as np
# Load a sample dataset
X, y = sklearn.datasets.load_breast_cancer(return_X_y=True)
data= sklearn.datasets.load_breast_cancer(as_frame=True)

# Split the dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train an XGBoost classifier
model = xgb.XGBClassifier(max_depth= 20 , random_state=42)
model.fit(X_train, y_train)

BC = sklearn.datasets.load_breast_cancer()
df = pd.DataFrame(data=BC.data, columns=BC.feature_names)
df['target'] = BC.target

explainer = shap.Explainer(model)
# Calculate SHAP values
shap_values = explainer(X_train)

feature_importances = pd.DataFrame({
    'Feature': data.feature_names,
    'Importance': np.abs(shap_values.values).mean(axis=0)
})

# Sort features by importance
feature_importances = feature_importances.sort_values(by='Importance', ascending=False)

booster = model.get_booster()
trees_df = booster.trees_to_dataframe()

def switch(feature_names, series):
    # Create a mapping dictionary
    feature_map = {f'f{i+1}': name for i, name in enumerate(feature_names)}
    # Map the series using the dictionary
    return series.map(feature_map)

trees_df['Feature1'] = switch(data['feature_names'], trees_df['Feature'])
trees_df['Feature1'] = trees_df['Feature1'].str.replace(" ", "_", regex=False)
trees_df['Feature1'] = trees_df['Feature1'].fillna('Leaf')


def get_rules(tree_no, index, leaf_id):
    # Initialize the list to store the rule path
    rules = []
    
    # Start with the leaf node
    current_node = trees_df[trees_df['ID'] == leaf_id]
    
    while not current_node.empty:
        feature = current_node['Feature1'].values[0]
        split = current_node['Split'].values[0]
        parent_id = current_node['Node'].values[0]
        # Determine if the current node is a 'Yes' or 'No' branch from its parent
        parent_node = trees_df[trees_df['Yes'] == leaf_id] if not trees_df[trees_df['Yes'] == leaf_id].empty else trees_df[trees_df['No'] == leaf_id]
        if parent_node.empty:
            break
        
        parent_feature = parent_node['Feature1'].values[0]
        parent_split = parent_node['Split'].values[0]
        
        if leaf_id in parent_node['Yes'].values:
            rule = f"{parent_feature} <= {parent_split}"
        else:
            rule = f"{parent_feature} > {parent_split}"
        
        rules.append(rule)
        
        # Move to the parent node
        leaf_id = parent_node['ID'].values[0]
        current_node = parent_node
    
    # Reverse the rules to get the correct order from root to leaf
    rules.reverse()
    
    # Print the rule path and the class prediction at the leaf
    #predicted_class = 1 if current_node['Gain'].values[0] > 0 else 0
    rule_path = " and ".join(rules)
    return(f"Tree {tree_no} - Rule {index}: {rule_path} -> {current_node['Gain'].values[0]}")

ruleset=[]
for tree_no in range(100):

    current_tree = trees_df[trees_df['Tree']==tree_no]

    leaf_nodes = current_tree[current_tree['Feature1'] == 'Leaf']

    # Get IDs of leaf nodes
    leaf_ids = leaf_nodes['ID'].tolist()
    for index,id in enumerate(leaf_ids):
        rule = get_rules(tree_no, index, id)
        ruleset.append(rule)
        #print(rule)

def condition_extraction(ruleset):
    # Pattern to match everything after the colon and before the arrow
    pattern_initial = r'(?<=:\s)(.*?)(?=\s->)'
    
    # Find all matches
    matches = re.findall(pattern_initial, ruleset)

    conditions = []
    if matches:
        # Extract the first match which contains all conditions
        condition_string = matches[0]
        
        # Pattern to separate conditions by 'and'
        pattern = r'\s+and\s+'
        
        # Split the condition string using 'and' keyword
        conditions = re.split(pattern, condition_string)
        
        # Strip any leading or trailing spaces
        conditions = [cond.strip() for cond in conditions]

    return conditions

def check_conditions(data_point_dict, conditions):
    extracted_conditions=  condition_extraction(conditions)
    for condition in extracted_conditions:

        pattern_for_feature =r'[A-Za-z_]+'
        feature_match = re.search(pattern_for_feature, condition)
        
        pattern_for_symbol = r'[<>=]+'
        symbol_match = re.search(pattern_for_symbol, condition)
        
        pattern_for_value = r'[-+]?\d*\.?\d+'
        value_match = re.search(pattern_for_value, condition)
        
        if feature_match and symbol_match and value_match:
            # Extract the matched groups
            fea=[]
            feature = feature_match.group()
            symbol = symbol_match.group()
            value = (value_match.group())
            feature = feature.split('_')
            for i in range(len(feature)):
                fea.append(f'{feature[i]} ')
            feature = "".join(fea)
            feature_value = data_point_dict[feature[:-1]]
            expression = f"{feature_value} {symbol} {value}"
            if not eval(expression): 
                return False
    return True


def get_neigbors(ruleset, data_points):
    neighbors = []
    counter = 0
    for index in range(len(data_points)):
        dictionary = dict(df.iloc[index].squeeze())
        check = check_conditions(dictionary,ruleset)
        #print(check, index)
        if check == True:
            neighbors.append(index)
            counter +=1
            #print(counter)
    return neighbors

leaf_neighborhoods = []
for rule in ruleset:
    
    leaf_neighborhoods.append((get_neigbors(rule,df)))